<?php defined('SYSPATH') OR die('No direct script access.');

class Form extends Kohana_Form {}

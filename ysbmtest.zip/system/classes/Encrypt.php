<?php defined('SYSPATH') OR die('No direct script access.');

class Encrypt extends Kohana_Encrypt {}

<?php

defined('SYSPATH') OR die('No direct access allowed.');
return array
    (
    'default' => array(
        'type' => 'PDO',
        'connection' => array(
            'dsn' => 'mysql:host=localhost;dbname=ysbmtest',
			'username' => 'root',
			'password' => 'y2qiBWNxe5',
            'persistent' => FALSE,
        ),
        'table_prefix' => '',
        'charset' => 'utf8',
        'caching' => FALSE,
    ),
);

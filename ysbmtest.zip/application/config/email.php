<?php

defined('SYSPATH') OR die('No direct access allowed.');
return array(
    'driver' => 'native',
    'options' => NULL
);

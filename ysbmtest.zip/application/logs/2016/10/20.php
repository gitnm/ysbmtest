<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2016-10-20 06:15:55 --- EMERGENCY: Database_Exception [ 1045 ]: SQLSTATE[28000] [1045] Access denied for user 'root'@'localhost' (using password: NO) ~ MODPATH/database/classes/Kohana/Database/PDO.php [ 59 ] in /var/www/sites/data/www/ships.komputernews.ru/modules/database/classes/Kohana/Database/PDO.php:136
2016-10-20 06:15:55 --- DEBUG: #0 /var/www/sites/data/www/ships.komputernews.ru/modules/database/classes/Kohana/Database/PDO.php(136): Kohana_Database_PDO->connect()
#1 /var/www/sites/data/www/ships.komputernews.ru/modules/database/classes/Kohana/Database/Query.php(251): Kohana_Database_PDO->query(1, 'SELECT * FROM c...', false, Array)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Model/category.php(12): Kohana_Database_Query->execute()
#3 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site.php(16): Model_Category->select_cat()
#4 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(69): Controller_Site->before()
#5 [internal function]: Kohana_Controller->execute()
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#10 {main} in /var/www/sites/data/www/ships.komputernews.ru/modules/database/classes/Kohana/Database/PDO.php:136
2016-10-20 06:31:32 --- EMERGENCY: ErrorException [ 1 ]: Class 'Email' not found ~ APPPATH/classes/Controller/Site/Registration.php [ 26 ] in file:line
2016-10-20 06:31:32 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-20 06:38:05 --- EMERGENCY: ErrorException [ 1 ]: Class 'Email' not found ~ APPPATH/classes/Controller/Site/Registration.php [ 26 ] in file:line
2016-10-20 06:38:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-20 06:41:28 --- EMERGENCY: ErrorException [ 1 ]: Class 'Email' not found ~ APPPATH/classes/Controller/Site/Registration.php [ 26 ] in file:line
2016-10-20 06:41:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-20 06:41:37 --- EMERGENCY: ErrorException [ 1 ]: Class 'Email' not found ~ APPPATH/classes/Controller/Site/Registration.php [ 26 ] in file:line
2016-10-20 06:41:37 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-20 06:44:55 --- EMERGENCY: ErrorException [ 2 ]: is_writable(): open_basedir restriction in effect. File(/tmp) is not within the allowed path(s): (/var/www/sites/data) ~ MODPATH/email/vendor/swift/preferences.php [ 15 ] in file:line
2016-10-20 06:44:55 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'is_writable(): ...', '/var/www/sites/...', 15, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/modules/email/vendor/swift/preferences.php(15): is_writable('/tmp')
#2 /var/www/sites/data/www/ships.komputernews.ru/modules/email/vendor/swift/swift_init.php(34): require_once('/var/www/sites/...')
#3 /var/www/sites/data/www/ships.komputernews.ru/modules/email/vendor/swift/swift_required.php(35): require_once('/var/www/sites/...')
#4 /var/www/sites/data/www/ships.komputernews.ru/modules/email/classes/Email.php(30): require('/var/www/sites/...')
#5 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Registration.php(26): Email::connect(Object(Config_Group))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Registration->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Registration))
#9 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#12 {main} in file:line
2016-10-20 06:46:27 --- EMERGENCY: ErrorException [ 2 ]: is_writable(): open_basedir restriction in effect. File(/tmp) is not within the allowed path(s): (/var/www/sites/data) ~ MODPATH/email/vendor/swift/preferences.php [ 15 ] in file:line
2016-10-20 06:46:27 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'is_writable(): ...', '/var/www/sites/...', 15, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/modules/email/vendor/swift/preferences.php(15): is_writable('/tmp')
#2 /var/www/sites/data/www/ships.komputernews.ru/modules/email/vendor/swift/swift_init.php(34): require_once('/var/www/sites/...')
#3 /var/www/sites/data/www/ships.komputernews.ru/modules/email/vendor/swift/swift_required.php(35): require_once('/var/www/sites/...')
#4 /var/www/sites/data/www/ships.komputernews.ru/modules/email/classes/Email.php(30): require('/var/www/sites/...')
#5 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Registration.php(26): Email::connect(Object(Config_Group))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Registration->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Registration))
#9 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#12 {main} in file:line
2016-10-20 06:58:55 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ''Subject: Test mime message'' (T_CONSTANT_ENCAPSED_STRING) ~ APPPATH/classes/Controller/Site/Index.php [ 16 ] in file:line
2016-10-20 06:58:55 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-20 07:03:36 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: subject ~ APPPATH/classes/Controller/Site/Index.php [ 14 ] in /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php:14
2016-10-20 07:03:36 --- DEBUG: #0 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(14): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/sites/...', 14, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#4 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#7 {main} in /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php:14
2016-10-20 07:04:08 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: subject ~ APPPATH/classes/Controller/Site/Index.php [ 14 ] in /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php:14
2016-10-20 07:04:08 --- DEBUG: #0 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(14): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/sites/...', 14, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#4 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#7 {main} in /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php:14
2016-10-20 07:16:44 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known ~ APPPATH/classes/Controller/Site/Index.php [ 980 ] in file:line
2016-10-20 07:16:44 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): ph...', '/var/www/sites/...', 980, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(980): fsockopen('smtp.asd.com', 25, 0, 'php_network_get...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(1207): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 07:20:46 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 07:20:46 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): ph...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.asd.com', 25, 0, 'php_network_get...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(22): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 07:21:44 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 07:21:44 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): ph...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.asd.com', 25, 0, 'php_network_get...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(20): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 07:23:04 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 07:23:04 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): ph...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.asd.com', 25, 0, 'php_network_get...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(20): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 07:23:05 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 07:23:05 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): ph...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.asd.com', 25, 0, 'php_network_get...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(20): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 07:33:33 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): unable to connect to pop.mail.ru:25 (Connection refused) ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 07:33:33 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): un...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('pop.mail.ru', 25, 111, 'Connection refu...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(20): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 07:37:22 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): unable to connect to smtp.gmail.com:25 (Network is unreachable) ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 07:37:22 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): un...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.gmail.com', 25, 101, 'Network is unre...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(20): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 08:27:35 --- EMERGENCY: ErrorException [ 1 ]: Class 'SMTP' not found ~ APPPATH/vendor/PHPMailer/class.phpmailer.php [ 1466 ] in file:line
2016-10-20 08:27:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-20 08:30:53 --- EMERGENCY: ErrorException [ 1 ]: Class 'SMTP' not found ~ APPPATH/vendor/PHPMailer/class.phpmailer.php [ 1466 ] in file:line
2016-10-20 08:30:53 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-20 08:32:43 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): unable to connect to smtp.yandex.ru:25 (Connection timed out) ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 08:32:43 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): un...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.yandex.ru', 25, 110, 'Connection time...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(31): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 08:32:48 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): unable to connect to smtp.yandex.ru:25 (Network is unreachable) ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 08:32:48 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): un...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.yandex.ru', 25, 101, 'Network is unre...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(31): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 08:32:53 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): unable to connect to smtp.yandex.ru:25 (Connection timed out) ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 08:32:53 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): un...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.yandex.ru', 25, 110, 'Connection time...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(31): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 08:33:30 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): unable to connect to smtp.yandex.ru:25 (Network is unreachable) ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 08:33:30 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): un...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.yandex.ru', 25, 101, 'Network is unre...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(31): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 08:33:35 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): unable to connect to smtp.yandex.ru:25 (Connection timed out) ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 08:33:35 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): un...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.yandex.ru', 25, 110, 'Connection time...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(31): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 08:33:58 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): unable to connect to smtp.yandex.ru:25 (Connection refused) ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 08:33:58 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): un...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.yandex.ru', 25, 111, 'Connection refu...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(31): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 08:34:03 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): unable to connect to smtp.yandex.ru:25 (Network is unreachable) ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 08:34:03 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): un...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('smtp.yandex.ru', 25, 101, 'Network is unre...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(31): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 08:44:42 --- EMERGENCY: ErrorException [ 2 ]: fsockopen(): unable to connect to ss://smtp.gmail.com:465 (Unable to find the socket transport &quot;ss&quot; - did you forget to enable it when you configured PHP?) ~ APPPATH/vendor/Libmail.php [ 1137 ] in file:line
2016-10-20 08:44:42 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'fsockopen(): un...', '/var/www/sites/...', 1137, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1137): fsockopen('ss://smtp.gmail...', 465, 0, 'Unable to find ...', 5)
#2 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(31): Mail->Send()
#3 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#9 {main} in file:line
2016-10-20 09:06:53 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: From ~ APPPATH/vendor/Libmail.php [ 1134 ] in /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php:1134
2016-10-20 09:06:53 --- DEBUG: #0 /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php(1134): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/sites/...', 1134, Array)
#1 /var/www/sites/data/www/ships.komputernews.ru/application/classes/Controller/Site/Index.php(31): Mail->Send()
#2 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Controller.php(84): Controller_Site_Index->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Index))
#5 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 /var/www/sites/data/www/ships.komputernews.ru/system/classes/Kohana/Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/sites/data/www/ships.komputernews.ru/index.php(118): Kohana_Request->execute()
#8 {main} in /var/www/sites/data/www/ships.komputernews.ru/application/vendor/Libmail.php:1134
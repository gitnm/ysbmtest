<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Site extends Controller_Base {

    public function before() {
        parent::before();
        $this->template->styles[] = 'media/css/bootstrap.min.css';
        $this->template->styles[] = 'media/css/offcanvas.css';
        $this->template->scripts[] = 'media/js/jquery.min.js';
        $this->template->scripts[] = 'media/js/bootstrap.min.js';
        $this->template->scripts[] = 'media/js/offcanvas.js';
        $this->template->styles[] = 'media/css/style.css';
        $this->template->category = Model::factory('category')->select_cat();
    }

}

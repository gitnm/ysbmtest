<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Admin_Index extends Controller_Admin {

    public $template = 'admin/template_0';

    public function before() {
        parent::before();
        if (!isset($_SESSION['user_id'])) {
            HTTP::redirect(URL::base());
        }
        if ($_SESSION['user_state'] != 2) {
            HTTP::redirect(URL::base());
        }
    }

    public function action_index() {
        $this->template->page_title = 'Главная';
        $index = View::factory('admin/index/index');
        $this->template->content = array($index);
    }

    public function action_logout() {
        unset($_SESSION['user_id']);
        unset($_SESSION['user_login']);
        unset($_SESSION['user_state']);
        HTTP::redirect(URL::base());
    }

}

<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Admin_Users extends Controller_Admin {

    public $template = 'admin/template_0';
    public $question = NULL;
    public $state = NULL;

    public function before() {
        parent::before();
        if (!isset($_SESSION['user_id'])) {
            HTTP::redirect(URL::base());
        }
        if ($_SESSION['user_state'] != 2) {
            HTTP::redirect(URL::base());
        }
        $this->question = Model::factory('user')->select_question();
        $this->state = Model::factory('user')->select_state();
    }

    public function action_index() {
        $this->template->page_title = 'Пользователи';
        $users = Model::factory('user')->select();
        $index = View::factory('admin/users/index', array(
                    'users' => $users,
                    'question' => $this->question,
                    'state' => $this->state
        ));
        $this->template->content = array($index);
    }

    public function action_add() {
        $id = $this->request->param('id');
        $this->template->page_title = 'Добавления пользователя';
        $index = View::factory('admin/users/form', array(
                    'question' => $this->question,
                    'state' => $this->state
        ));
        $this->template->content = array($index);
    }

    public function action_edit() {
        $id = $this->request->param('id');
        $this->template->page_title = 'Редактирование пользователя';
        $user = Model::factory('user')->select_users_by_id($id);
        $index = View::factory('admin/users/form', array(
                    'user' => $user,
                    'question' => $this->question,
                    'state' => $this->state
        ));
        $this->template->content = array($index);
    }

    public function action_delete() {
        $id = $this->request->param('id');
        Model::factory('user')->delete($id);
        HTTP::redirect(URL::base() . 'admin/users');
    }

    public function action_save() {
        $data = array(
            'id' => (int) $_POST['id'],
            'login' => (isset($_POST['login'])) ? $_POST['login'] : NULL,
            'pass' => (isset($_POST['pass'])) ? $_POST['pass'] : NULL,
            'email' => (isset($_POST['email'])) ? $_POST['email'] : NULL,
            'question' => (isset($_POST['question'])) ? $_POST['question'] : NULL,
            'answer' => (isset($_POST['answer'])) ? $_POST['answer'] : NULL,
            'state' => (isset($_POST['state'])) ? $_POST['state'] : NULL
        );
        $mas = array_search(NULL, $data);
        if ($mas === 'id' || $mas === FALSE) {
            if ($data['id'] !== 0) {
				$vpass = (isset($_POST['vpass'])) ? $_POST['vpass'] : NULL;
				if ($data['pass'] != $vpass){
					$data['pass'] = md5($data['pass']);
				}
                Model::factory('user')->update($data);
            } else {
				$data['pass'] = md5($data['pass']);
                Model::factory('user')->insert($data);
            }
        }
        HTTP::redirect(URL::base() . 'admin/users');
    }

}

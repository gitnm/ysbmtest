<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Admin_Category extends Controller_Admin {

    public $template = 'admin/template_0';

    public function before() {
        parent::before();
        if (!isset($_SESSION['user_id'])) {
            HTTP::redirect(URL::base());
        }
        if ($_SESSION['user_state'] != 2) {
            HTTP::redirect(URL::base());
        }
    }

    public function action_index() {
        $this->template->page_title = 'Категории';
        $category = Model::factory('category')->select();
        $visible = Model::factory('category')->select_visible();
        $index = View::factory('admin/category/index', array(
                    'category' => $category,
                    'visible' => $visible
        ));
        $this->template->content = array($index);
    }

    public function action_add() {
        $this->template->page_title = 'Добавление категории';
        $visible = Model::factory('category')->select_visible();
        $index = View::factory('admin/category/form', array(
                    'visible' => $visible
        ));
        $this->template->content = array($index);
    }

    public function action_edit() {
        $id = $this->request->param('id');
        $this->template->page_title = 'Редактирование категории';
        $visible = Model::factory('category')->select_visible();
        $category = Model::factory('category')->select_category_by_id($id);
        $index = View::factory('admin/category/form', array(
                    'category' => $category,
                    'visible' => $visible
        ));
        $this->template->content = array($index);
    }

    public function action_delete() {
        $id = $this->request->param('id');
        Model::factory('category')->delete($id);
        HTTP::redirect(URL::base() . 'admin/category');
    }

    public function action_save() {
        $data = array(
            'id' => (int) $_POST['id'],
            'category' => (isset($_POST['category'])) ? $_POST['category'] : NULL,
            'visible' => (isset($_POST['visible'])) ? $_POST['visible'] : NULL
        );
        $mas = array_search(NULL, $data);
        if ($mas === 'id' || $mas === FALSE) {
            if ($data['id'] !== 0) {
                Model::factory('category')->update($data);
            } else {
                Model::factory('category')->insert($data);
            }
        }
        HTTP::redirect(URL::base() . 'admin/category');
    }

}

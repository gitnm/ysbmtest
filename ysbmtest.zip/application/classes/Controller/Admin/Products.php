<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Admin_Products extends Controller_Admin {

    public $template = 'admin/template_0';
    public $visible = NULL;

    public function before() {
        parent::before();
        if (!isset($_SESSION['user_id'])) {
            HTTP::redirect(URL::base());
        }
        if ($_SESSION['user_state'] != 2) {
            HTTP::redirect(URL::base());
        }
        $this->visible = Model::factory('category')->select_visible();
    }

    public function action_index() {
        $this->template->page_title = 'Продукты';
        $products = Model::factory('product')->select_products_and_category();
        $index = View::factory('admin/products/index', array(
                    'products' => $products,
                    'visible' => $this->visible
        ));
        $this->template->content = array($index);
    }

    public function action_add() {
        $id = $this->request->param('id');
        $this->template->page_title = 'Добавление продукта';
        $category = Model::factory('category')->select();
        $index = View::factory('admin/products/form', array(
                    'category' => $category,
                    'visible' => $this->visible
        ));
        $this->template->content = array($index);
    }

    public function action_edit() {
        $id = $this->request->param('id');
        $this->template->page_title = 'Редактирование продукта';
        $product = Model::factory('product')->select_products_by_id($id);
        $category = Model::factory('category')->select();
        $index = View::factory('admin/products/form', array(
                    'product' => $product,
                    'category' => $category,
                    'visible' => $this->visible
        ));
        $this->template->content = array($index);
    }

    public function action_delete() {
        $id = $this->request->param('id');
        Model::factory('product')->delete($id);
        HTTP::redirect(URL::base() . 'admin/products');
    }

    public function action_save() {
        $data = array(
            'id' => (int) $_POST['id'],
            'category_id' => (isset($_POST['category_id'])) ? $_POST['category_id'] : NULL,
            'title' => (isset($_POST['title'])) ? $_POST['title'] : NULL,
            'info' => (isset($_POST['info'])) ? $_POST['info'] : NULL,
            'visible' => (isset($_POST['visible'])) ? $_POST['visible'] : NULL,
        );
        $mas = array_search(NULL, $data);
        if ($mas === 'id' || $mas === FALSE) {
            if ($data['id'] !== 0) {
                Model::factory('product')->update($data);
            } else {
                Model::factory('product')->insert($data);
            }
        }
        HTTP::redirect(URL::base() . 'admin/products');
    }

    public function action_create() {
        if (Request::initial()->is_ajax()) {
            $id = (int) $_POST['id'];
            $uploaddir = 'media/img/products/';
            if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0) {
                $path = pathinfo($_FILES['file']['name']);
                $file_name = date('YmdHis') . '.' . $path['extension'];
                Upload::save($_FILES['file'], $file_name, $uploaddir);
                Model::factory('product')->update(array('id' => $id, 'img' => $file_name));
            }
            header('Content-Type: text/html; charset=utf-8');
            exit;
        } else {
            HTTP::redirect(URL::base() . 'admin/products');
        }
    }

    public function action_features() {
        $id = $this->request->param('id');
        $this->template->page_title = 'Характеристики продукта';
        $features = Model::factory('feature')->select_features_by_id($id);
        $index = View::factory('admin/features/form', array(
                    'id' => $id,
                    'features' => $features
        ));
        $this->template->content = array($index);
    }

    public function action_feature_save() {
        $data = array(
            'product_id' => (int) $_POST['product_id'],
            'name' => (isset($_POST['name'])) ? $_POST['name'] : NULL,
            'value' => (isset($_POST['value'])) ? $_POST['value'] : NULL,
        );
        $mas = array_search(NULL, $data);
        if ($mas === FALSE) {
            Model::factory('feature')->insert($data);
            HTTP::redirect(URL::base() . 'admin/products/features/' . $data['product_id']);
        } else {
            HTTP::redirect(URL::base() . 'admin/products');
        }
    }

    public function action_feature_delete() {
        if (Request::initial()->is_ajax()) {
            Model::factory('feature')->delete((int) $_POST['id']);
            header('Content-Type: text/html; charset=utf-8');
            exit;
        }
    }

}

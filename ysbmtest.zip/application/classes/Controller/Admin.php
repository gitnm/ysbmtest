<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Admin extends Controller_Base {

    public function before() {
        parent::before();
        $this->template->styles[] = 'media/css/bootstrap.min.css';
        $this->template->styles[] = 'media/css/metisMenu.css';
        $this->template->styles[] = 'media/css/sb-admin-2.css';
        $this->template->scripts[] = 'media/js/jquery.min.js';
        $this->template->scripts[] = 'media/js/bootstrap.min.js';
        $this->template->scripts[] = 'media/js/metisMenu.js';
        $this->template->scripts[] = 'media/js/sb-admin-2.js';
        $navigation = View::factory('admin/navigation/navigation');
        $this->template->sitebar = array($navigation);
    }

}

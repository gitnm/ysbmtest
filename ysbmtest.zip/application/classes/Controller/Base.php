<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Base extends Controller_Template {

    public function before() {
        parent::before();
        $this->template->site_name = 'YSBM Test';
        $this->template->site_description = 'YSBM Test';
        $this->template->page_title = 'YSBM Test';
        $this->template->styles = array();
        $this->template->scripts = array();
        $this->template->content = array();
        $this->template->sitebar = array();
        $this->template->navigation = NULL;
    }

}

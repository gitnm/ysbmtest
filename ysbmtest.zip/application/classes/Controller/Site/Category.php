<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Site_Category extends Controller_Site {

    public $template = 'site/template_0';

    public function action_index() {
        $id = (int) $this->request->param('id');
        $products = Model::factory('product')->select_products_by_category($id);
        $content = View::factory('site/category/index', array('products' => $products));
        $this->template->content = array($content);
    }

    public function action_product() {
        $id = (int) $this->request->param('id');
        $product = Model::factory('product')->select_products_by_id($id);
        $features = Model::factory('feature')->select_features_by_id($id);
        $content = View::factory('site/category/product', array(
                    'product' => $product,
                    'features' => $features
        ));
        $this->template->content = array($content);
    }

}

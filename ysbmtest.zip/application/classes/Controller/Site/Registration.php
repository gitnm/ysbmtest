<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Site_Registration extends Controller_Site {

    public $template = 'site/template_0';

    public function action_index() {
        $content = View::factory('site/registration/index');
        $this->template->content = array($content);
    }

    public function action_send() {
        $data = array(
            'login' => (isset($_POST['login'])) ? $_POST['login'] : NULL,
            'pass' => (isset($_POST['pass'])) ? md5($_POST['pass']) : NULL,
            'email' => (isset($_POST['email'])) ? $_POST['email'] : NULL,
            'question' => (isset($_POST['question'])) ? $_POST['question'] : NULL,
            'answer' => (isset($_POST['answer'])) ? $_POST['answer'] : NULL
        );
        if (!empty($data['login']) && !empty($data['pass']) && !empty($data['pass'])) {
            Model::factory('user')->insert($data);

			require_once Kohana::find_file('vendor/PHPMailer', 'PHPMailerAutoload', 'php');			
			$mail = new PHPMailer;
			$mail->isSMTP();
			$mail->Host = 'smtp.gmail.com';
			$mail->SMTPAuth = true;  
			$mail->SMTPSecure = 'ssl';
			$mail->Port = 465;                         
			$mail->CharSet = 'UTF-8';
			$mail->Username = 'Nicterminal@gmail.com';           
			$mail->Password = 'Terminal09111989';                      
			$mail->setFrom('ysbmtest@gmail.com', 'YSBM');
			$mail->addAddress($data['email'], $data['login']);
			$mail->isHTML(true);
			$mail->Subject = 'Регистрация YSBM Test';
			$mail->Body    = 'Для подтверждения регистрации перейдите по ссылке: ' .
				URL::base() . 'registration/confirm/' . $data['pass'] . ' или скопируйте ее в адресную строку браузера.';
			if(!$mail->send()) {
				$content = '<h1>Ошибка. Письмо не отправлено</h1>';
			} else {
				$content = '<h1>На Ваш E-mail отправлено письмо</h1>';
			}

            $this->template->content = array($content);
        } else {
            HTTP::redirect(URL::base() . 'registration');
        }
    }

    public function action_confirm() {
        $id = Model::factory('user')->confirm($this->request->param('id'));
        if ($id > 0) {
            Model::factory('user')->update(array('id' => $id, 'state' => 1));
            (isset($_SESSION['user_state'])) ? $_SESSION['user_state'] = 1 : NULL;
            $msg = 'Вы успешно прошли регистрацию на YSBM Test';
        } else {
            $msg = 'Ключ не валидный с уважением YSBM Test';
        }
        $content = View::factory('site/registration/confirm', array('msg' => $msg));
        $this->template->content = array($content);
    }

}

<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Site_Index extends Controller_Site {

    public $template = 'site/template_0';

    public function action_index() {
        $category = Model::factory('category')->select_cat();
        $content = View::factory('site/index/index', array('category' => $category));
        $this->template->content = array($content);
    }

    public function action_login() {
        $login = (isset($_POST['login']) && !empty($_POST['login'])) ? $_POST['login'] : FALSE;
        $pass = (isset($_POST['pass']) && !empty($_POST['pass'])) ? $_POST['pass'] : FALSE;
        if ($login !== FALSE || $pass !== FALSE) {
            $user = Model::factory('user')->login($login, $pass);
            if ($user) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_login'] = $user['login'];
                $_SESSION['user_state'] = $user['state'];
                ($user['state'] == 2) ? HTTP::redirect(URL::base() . 'admin') : NULL;
            }
            HTTP::redirect(URL::base());
        } else {
            HTTP::redirect(URL::base());
        }
    }

    public function action_logout() {
        unset($_SESSION['user_id']);
        unset($_SESSION['user_login']);
        unset($_SESSION['user_state']);
        HTTP::redirect(URL::base());
    }

}

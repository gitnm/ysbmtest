<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Site_Recovery extends Controller_Site {

    public $template = 'site/template_0';

    public function action_index() {
        $content = View::factory('site/recovery/index');
        $this->template->content = array($content);
    }

    public function action_send() {
        $data = array(
            'email' => (isset($_POST['email'])) ? $_POST['email'] : NULL,
            'question' => (isset($_POST['question'])) ? (int) $_POST['question'] : NULL,
            'answer' => (isset($_POST['answer'])) ? $_POST['answer'] : NULL
        );
        if (!empty($data['email']) && !empty($data['question']) && !empty($data['answer'])) {
            $id = Model::factory('user')->recovery($data);
            if ($id > 0) {
                $pass = $this->get_pass();
                Model::factory('user')->update(array('pass' => md5($pass), 'id' => $id));

				
				require_once Kohana::find_file('vendor/PHPMailer', 'PHPMailerAutoload', 'php');			
				$mail = new PHPMailer;
				$mail->isSMTP();
				$mail->Host = 'smtp.gmail.com';
				$mail->SMTPAuth = true;  
				$mail->SMTPSecure = 'ssl';
				$mail->Port = 465;                         
				$mail->CharSet = 'UTF-8';
				$mail->Username = 'Nicterminal@gmail.com';           
				$mail->Password = 'Terminal09111989';                      
				$mail->setFrom('ysbmtest@gmail.com', 'YSBM');
				$mail->addAddress($data['email'], 'Joe User');
				$mail->isHTML(true);
				$mail->Subject = 'Восстановление пароля YSBM Test';
				$mail->Body    = 'Ваш новый пароль в YSBM Test: ' . $pass;
				if(!$mail->send()) {
					$content = '<h1>Ошибка. Письмо не отправлено</h1>';
				} else {
					$content = '<h1>На Ваш E-mail отправлено письмо</h1>';
				}

                $content = View::factory('site/recovery/vemail');
                $this->template->content = array($content);
            } else {
                HTTP::redirect(URL::base() . 'recovery');
            }
        } else {
            HTTP::redirect(URL::base() . 'recovery');
        }
    }

    private function get_pass() {
        $max = 10;
        $chars = "qazxswedcvfrtgbnhyujmkiolp1234567890QAZXSWEDCVFRTGBNHYUJMKIOLP";
        $size = StrLen($chars) - 1;
        $pass = NULL;
        while ($max--)
            $pass .= $chars[rand(0, $size)];
        return $pass;
    }

}

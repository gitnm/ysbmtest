<?php

defined('SYSPATH') or die('No direct script access.');

class Model_Category extends Model {

    public function select_cat() {
        (isset($_SESSION['user_state'])) ? $visible = array(0, $_SESSION['user_state']) : $visible = array(0);
        $query = DB::select()
                ->from('category')
                ->and_where('visible', 'IN', $visible);
        $result = $query->execute();
        return $result;
    }

    public function select() {
        $query = DB::select()
                ->from('category');
        $result = $query->execute();
        return $result;
    }

    public function select_category_by_id($id) {
        $query = DB::select()
                ->from('category')
                ->where('id', '=', $id);
        $result = $query->execute();
        return $result[0];
    }

    public function update($param) {
        $data = array();
        foreach ($param as $k => $v) {
            $data['`' . $k . '`'] = $v;
        }
        DB::update('category')->set($data)->where('id', '=', $param['id'])->execute();
    }

    public function insert($param) {
        DB::insert('category', array('`' . implode('`,`', array_keys($param)) . '`'))->values(array_values($param))->execute();
    }

    public function delete($id) {
        DB::delete('category')->where('id', '=', $id)->execute();
    }

    public function select_visible() {
        return array(
            '' => 'Выбрать',
            0 => 'Виден всем',
            1 => 'Виден только зарегистрированным пользователям',
            2 => 'Виден только администратору'
        );
    }

}

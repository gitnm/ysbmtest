<?php

defined('SYSPATH') or die('No direct script access.');

class Model_Product extends Model {

    public function select_products_and_category() {
        $query = DB::select('*,products.id as product_id, products.visible as product_visible')
                ->from('products')
                ->join('category')
                ->on('products.category_id', '=', 'category.id');
        $result = $query->execute();
        return $result;
    }

    public function select_products_by_category($id) {
        (isset($_SESSION['user_state'])) ? $visible = array(0, $_SESSION['user_state']) : $visible = array(0);
        $query = DB::select()
                ->from('products')
                ->where('category_id', '=', $id)
                ->and_where('products.visible', 'IN', $visible);
        $result = $query->execute();
        return $result;
    }

    public function select_products_by_id($id) {
        $query = DB::select()
                ->from('products')
                ->where('id', '=', $id);
        $result = $query->execute();
        return $result[0];
    }

    public function update($param) {
        $data = array();
        foreach ($param as $k => $v) {
            $data['`' . $k . '`'] = $v;
        }
        DB::update('products')->set($data)->where('id', '=', $param['id'])->execute();
    }

    public function insert($param) {
        DB::insert('products', array('`' . implode('`,`', array_keys($param)) . '`'))->values(array_values($param))->execute();
    }

    public function delete($id) {
        DB::delete('products')->where('id', '=', $id)->execute();
    }

}

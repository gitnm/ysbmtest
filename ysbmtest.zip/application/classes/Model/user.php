<?php

defined('SYSPATH') or die('No direct script access.');

class Model_User extends Model {

    public function select() {
        $query = DB::select()
                ->from('users');
        $result = $query->execute();
        return $result;
    }

    public function select_users_by_id($id) {
        $query = DB::select()
                ->from('users')
                ->where('id', '=', $id);
        $result = $query->execute();
        return $result[0];
    }

    public function login($login, $pass) {
        $query = DB::select()
                ->from('users')
                ->where('login', '=', $login)
                ->and_where('pass', '=', md5($pass))
                ->and_where('state', '!=', 0);
        $result = $query->execute();
        return $result[0];
    }

    public function confirm($key) {
        $query = DB::select('id')
                ->from('users')
                ->where('pass', '=', $key)
                ->limit(1);
        $result = $query->execute();
        return (int) $result[0]['id'];
    }

    public function recovery($data) {
        $query = DB::select('id')
                ->from('users')
                ->where('email', '=', $data['email'])
                ->and_where('question', '=', $data['question'])
                ->and_where('answer', '=', $data['answer'])
                ->limit(1);
        $result = $query->execute();
        return (int) $result[0]['id'];
    }

    public function update($param) {
        $data = array();
        foreach ($param as $k => $v) {
            $data['`' . $k . '`'] = $v;
        }
        DB::update('users')->set($data)->where('id', '=', $param['id'])->execute();
    }

    public function insert($param) {
        DB::insert('users', array('`' . implode('`,`', array_keys($param)) . '`'))->values(array_values($param))->execute();
    }

    public function delete($id) {
        DB::delete('users')->where('id', '=', $id)->execute();
    }

    public function select_question() {
        return array(
            '' => 'Выбрать',
            1 => 'Девичья фамилия матери',
            2 => 'Номер паспорта',
            3 => 'Имя домашнего питомца',
            4 => 'Марка любимого авто'
        );
    }

    public function select_state() {
        return array(
            '' => 'Выбрать',
            0 => 'Новый',
            1 => 'Активный',
            2 => 'Администратор'
        );
    }

}

<?php

defined('SYSPATH') or die('No direct script access.');

class Model_Feature extends Model {

    public function select_features_by_id($id) {
        $query = DB::select()
                ->from('features')
                ->where('product_id', '=', $id);
        $result = $query->execute();
        return $result;
    }

    public function insert($param) {
        DB::insert('features', array('`' . implode('`,`', array_keys($param)) . '`'))->values(array_values($param))->execute();
    }

    public function delete($id) {
        DB::delete('features')->where('id', '=', $id)->execute();
    }

}

<?php if (isset($products) && count($products) > 0): ?>
    <div class="row">
        <?php foreach ($products as $v): ?>
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail">
                    <?php echo HTML::image('media/img/products/' . $v['img'], array('style' => 'height: 200px;')); ?>
                    <div class="caption">
                        <h3 class="text-center" style="height: 50px;overflow: hidden;"><?php echo $v['title']; ?></h3>
                        <p style="height: 95px;overflow: hidden;"><?php echo $v['info']; ?></p>
                        <p class="text-center"><a href="<?php echo URL::base() . 'category/product/' . $v['id']; ?>" class="btn btn-default" role="button">Подробнее</a></p>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php else : ?>
    <h1>В категории пока еще нет товаров</h1>
<?php endif; ?>

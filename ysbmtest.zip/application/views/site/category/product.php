<?php if (isset($product) && count($product) > 0): ?>
    <div class="row">
        <div class="col-md-12">
            <h1><?php echo $product['title']; ?></h1>
            <div style="float: left;margin-right: 10px;margin-bottom: 10px;"><?php echo HTML::image('media/img/products/' . $product['img'], array('alt' => '', 'style' => 'width:150px;')); ?></div>
            <?php echo $product['info']; ?>
            <div class="clearfix"></div>
            <?php if (isset($features) && count($features) > 0): ?>
                <div class="panel-group">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" href="#collapse1">Характеристики</a>
                            </h4>
                        </div>
                        <div id="collapse1" class="panel-collapse collapse">
                            <div class="panel-body">
                                <table class="table table-striped">
                                    <tbody>
                                        <?php foreach ($features as $v): ?>
                                            <tr>
                                                <td><?php echo $v['name']; ?></td>
                                                <td><?php echo $v['value']; ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>
<?php if (isset($category) && count($category) > 0): ?>
    <div class="row">
        <?php foreach ($category as $v): ?>
            <div class="col-xs-6 col-md-3">
                <a href="<?php echo URL::base() . 'category/' . $v['id']; ?>" class="thumbnail">
                    <p class="text-center"><?php echo $v['category']; ?></p>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<h1>Восстановление пароля</h1>
<form role="form" id="form" action="<?php echo URL::base() . 'recovery/send'; ?>" method="POST">
    <label for="basic-url"></label>
    <div class="input-group">
        <span class="input-group-addon" id="basic-addon3" style="padding-right: 22px;">E-mail</span>
        <input type="text" class="form-control" id="basic-url" aria-describedby="basic-addon3" name="email">
    </div>
    <label for="basic-url"></label>
    <div class="form-group">
        <select name="question" class="form-control">
            <option value="" selected="">Выбрать</option>
            <option value="1">Девичья фамилия матери</option>
            <option value="2">Номер паспорта</option>
            <option value="3">Имя домашнего питомца</option>
            <option value="4">Марка любимого авто</option>
        </select>
    </div>
    <div class="input-group">
        <span class="input-group-addon" id="basic-addon3" style="padding-right: 22px;">Ответ</span>
        <input type="text" class="form-control" id="basic-url" aria-describedby="basic-addon3" name="answer">
    </div>
    <div class="text-right" style="margin-top: 10px;">
        <button type="submit" class="btn btn-success">Отправить</button>
    </div>
</form>

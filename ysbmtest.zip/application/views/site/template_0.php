<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo URL::base() . 'media/img/favicon.png'; ?>">
        <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <title><?php echo $page_title; ?></title>
        <?php foreach ($styles as $v): ?>
            <?php echo HTML::style($v); ?>
        <?php endforeach; ?>
        <?php foreach ($scripts as $v): ?>
            <?php echo HTML::script($v); ?>
        <?php endforeach; ?>
    </head>
    <body>
        <div class="navbar navbar-fixed-top navbar-inverse" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li><?php echo HTML::anchor('', 'Главная'); ?></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Категории <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <?php foreach ($category as $v): ?>
                                    <li><?php echo HTML::anchor('category/' . $v['id'], $v['category']); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <?php if (!isset($_SESSION['user_id'])): ?>
                                <div class="box-info">Добро пожаловать, Гость!<br>Роль доступа: незарегистрированный пользователь</div>
                            <?php endif; ?>
                            <?php if (isset($_SESSION['user_state']) && $_SESSION['user_state'] == 1): ?>
                                <div class="box-info">Добро пожаловать, <?php echo $_SESSION['user_login']; ?>!<br>Роль доступа: зарегистрированный пользователь</div>
                            <?php endif; ?>
                            <?php if (isset($_SESSION['user_state']) && $_SESSION['user_state'] == 2): ?>
                                <div class="box-info">Добро пожаловать, <?php echo $_SESSION['user_login']; ?>!<br>Роль доступа: Администратор</div>
                            <?php endif; ?>
                        </li>
                        <?php if (!isset($_SESSION['user_id'])): ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Вход <span class="caret"></span></a>
                                <ul class="dropdown-menu auth">
                                    <li style="width: 400px;">
                                        <div class="login-panel panel panel-default">
                                            <div class="panel-heading">
                                                <h3 class="panel-title">Аутентификация</h3>
                                            </div>
                                            <div class="panel-body">
                                                <form method="POST" action="<?php echo URL::base() . 'index/login'; ?>" id="login_form" novalidate>
                                                    <fieldset>
                                                        <div class="form-group">
                                                            <input class="form-control" placeholder="Логин" name="login" type="text" autocomplete="off" autofocus>
                                                        </div>
                                                        <div class="form-group">
                                                            <input class="form-control" placeholder="Password" name="pass" type="password" autocomplete="off" value="">
                                                        </div>
                                                        <button class="login btn btn-lg btn-success btn-block" type="submit">Вход</button>
                                                        <div style="margin-top: 10px;">
                                                            <?php echo HTML::anchor('registration', 'Регистрация'); ?><br/>
                                                            <?php echo HTML::anchor('recovery', 'Восстановление пароля'); ?>
                                                        </div>
                                                    </fieldset>
                                                </form>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                        <?php else : ?>
                            <li><?php echo HTML::anchor('index/logout', 'Выход') ?></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container content-sidebar">
            <div class="row row-offcanvas row-offcanvas-right">
                <div class="col-xs-12 col-sm-8" >
                    <?php foreach ($content as $v): ?>
                        <?php echo $v; ?>
                    <?php endforeach; ?>
                </div>
                <div class="col-xs-6 col-sm-4 sidebar-offcanvas" id="sidebar" role="navigation">
                    <?php foreach ($sitebar as $v): ?>
                        <?php echo $v; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </body>
</html>
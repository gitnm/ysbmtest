<form action="<?php echo URL::base() . 'admin/users/save'; ?>" method="POST">
    <div class="form-group hidden">
        <input class="form-group" name="id" value="<?php echo (isset($user['id'])) ? $user['id'] : NULL; ?>">
    </div>
    <div class="form-group">
        <label>Логин</label>
        <input class="form-control" name="login" value="<?php echo (isset($user['login'])) ? $user['login'] : NULL; ?>">
    </div>
    <div class="form-group">
        <label>Пароль</label>
        <input class="form-control" name="pass" value="<?php echo (isset($user['pass'])) ? $user['pass'] : NULL; ?>">
    </div>
	<div class="form-group hidden">
        <label>Пароль</label>
        <input class="form-control" name="vpass" value="<?php echo (isset($user['pass'])) ? $user['pass'] : NULL; ?>">
    </div>
    <div class="form-group">
        <label>E-mail</label>
        <input class="form-control" name="email" value="<?php echo (isset($user['email'])) ? $user['email'] : NULL; ?>">
    </div>
    <div class="form-group">
        <label>Вопрос</label>
        <select class="form-control" name="question">
            <?php foreach ($question as $k => $v): ?>
                <option value="<?php echo $k ?>" <?php echo (isset($user['question']) && $user['question'] == $k) ? 'selected' : NULL; ?>><?php echo $v; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Ответ</label>
        <input class="form-control" name="answer" value="<?php echo (isset($user['answer'])) ? $user['answer'] : NULL; ?>">
    </div>
    <div class="form-group">
        <label>Статус</label>
        <select class="form-control" name="state">
            <?php foreach ($state as $k => $v): ?>
                <option value="<?php echo $k ?>" <?php echo (isset($user['state']) && $user['state'] == $k) ? 'selected' : NULL; ?>><?php echo $v; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="text-center">
        <button type="submit" class="btn btn-success">Сохранить</button>
    </div>
</form>
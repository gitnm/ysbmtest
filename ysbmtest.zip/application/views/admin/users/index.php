<?php echo HTML::anchor('admin/users/add', 'Добавить пользователя', array('class' => 'btn btn-info')); ?>
<table class="table table-striped">
    <thead>
        <tr>
            <th>№</th>
            <th>Логин</th>
            <th>Пароль</th>
            <th>E-mail</th>
            <th>Вопрос</th>
            <th>Ответ</th>
            <th>Статус</th>
            <th>Действие</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $k => $v): ?>
            <tr>
                <td><?php echo ($k + 1); ?></td>
                <td><?php echo $v['login']; ?></td>
                <td><?php echo $v['pass']; ?></td>
                <td><?php echo $v['email']; ?></td>
                <td><?php echo $question[$v['question']]; ?></td>
                <td><?php echo $v['answer']; ?></td>
                <td><?php echo $state[$v['state']]; ?></td>
                <td>
                    <?php echo HTML::anchor('admin/users/edit/' . $v['id'], '<i class="fa fa-pencil"></i>'); ?>
                    <?php echo ($_SESSION['user_id'] != $v['id']) ? HTML::anchor('admin/users/delete/' . $v['id'], '<i class="fa fa-trash"></i>') : NULL; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
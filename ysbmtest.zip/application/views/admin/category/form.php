<form action="<?php echo URL::base() . 'admin/category/save'; ?>" method="POST">
    <div class="form-group hidden">
        <input class="form-control" name="id" value="<?php echo (isset($category['id'])) ? $category['id'] : NULL; ?>">
    </div>
    <div class="form-group">
        <label>Категория</label>
        <input class="form-control" name="category" value="<?php echo (isset($category['category'])) ? $category['category'] : NULL; ?>">
    </div>
    <div class="form-group">
        <label>Видимость</label>
        <select class="form-control" name="visible">
            <?php foreach ($visible as $k => $v): ?>
                <option value="<?php echo $k; ?>" <?php echo (isset($category['visible']) && $category['visible'] == $k) ? 'selected' : NULL; ?>><?php echo $v; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="text-center">
        <button type="submit" class="btn btn-success">Сохранить</button>
    </div>
</form>

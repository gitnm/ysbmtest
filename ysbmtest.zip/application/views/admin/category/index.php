<?php echo HTML::anchor('admin/category/add', 'Добавить сатегорию', array('class' => 'btn btn-info')); ?>
<table class="table table-striped">
    <thead>
        <tr>
            <th>№</th>
            <th>Категория</th>
            <th>Видимость</th>
            <th>Действие</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($category as $k => $v): ?>
            <tr>
                <td><?php echo ($k + 1); ?></td>
                <td><?php echo $v['category']; ?></td>
                <td><?php echo $visible[$v['visible']]; ?></td>
                <td>
                    <?php echo HTML::anchor('admin/category/edit/' . $v['id'], '<i class="fa fa-pencil"></i>') ?>
                    <?php echo HTML::anchor('admin/category/delete/' . $v['id'], '<i class="fa fa-trash"></i>') ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
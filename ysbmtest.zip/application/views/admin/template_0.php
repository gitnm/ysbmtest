<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="noindex, follow">
        <link rel="shortcut icon" href="<?php echo URL::base() . 'media/img/favicon.png'; ?>">
        <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <title>YSBM Admin</title>
        <?php foreach ($styles as $v): ?>
            <?php echo HTML::style($v); ?>
        <?php endforeach ?>
        <?php foreach ($scripts as $v): ?>
            <?php echo HTML::script($v); ?>
        <?php endforeach ?>
    </head>
    <body>
        <div id="wrapper">
            <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom:0;">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <?php echo HTML::anchor('admin', 'YSBM Admin', array('class' => 'navbar-brand')) ?>
                </div>
                <?php foreach ($sitebar as $v): ?>
                    <?php echo $v; ?>
                <?php endforeach ?>
            </nav>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header"><?php echo $page_title; ?></h1>
                    </div>
                </div>
                <div class="msg" style="display: none;"></div>
                <?php foreach ($content as $v): ?>
                    <div class="row">
                        <div class="col-lg-12"><?php echo $v; ?></div>
                    </div>
                <?php endforeach ?>
            </div>
        </div>
    </body>
</html>
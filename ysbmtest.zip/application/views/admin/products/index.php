<?php echo HTML::anchor('admin/products/add', 'Добавить продукт', array('class' => 'btn btn-info')); ?>
<table class="table table-striped">
    <thead>
        <tr>
            <th>№</th>
            <th>Категория</th>
            <th>Картинка</th>
            <th>Название</th>
            <th>Описание</th>
            <th>Видимость</th>
            <th>Действие</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($products as $k => $v): ?>
            <tr>
                <td><?php echo ($k + 1); ?></td>
                <td><?php echo $v['category']; ?></td>
                <td><?php echo HTML::image('media/img/products/' . $v['img'], array('style' => 'width:100px;')); ?></td>
                <td><?php echo $v['title']; ?></td>
                <td><?php echo UTF8::substr($v['info'], 0, 256) . '...'; ?></td>
                <td><?php echo $visible[$v['product_visible']]; ?></td>
                <td>
                    <?php echo HTML::anchor('admin/products/edit/' . $v['product_id'], '<i class="fa fa-pencil"></i>') ?>
                    <?php echo HTML::anchor('admin/products/features/' . $v['product_id'], '<i class="fa fa-cog"></i>') ?>
                    <?php echo HTML::anchor('admin/products/delete/' . $v['product_id'], '<i class="fa fa-trash"></i>') ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
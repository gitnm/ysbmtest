<form action="<?php echo URL::base() . 'admin/products/save'; ?>" method="POST">
    <div class="form-group hidden">
        <input class="form-group" name="id" value="<?php echo (isset($product['id'])) ? $product['id'] : NULL; ?>">
    </div>
    <div class="form-group">
        <label>Категория</label>
        <select class="form-control" name="category_id" id="category">
            <option value="" <?php echo (isset($product['category_id']) && empty($product['category_id'])) ? 'selected' : NULL; ?>>Выбрать</option>
            <?php if (isset($category) && count($category) > 0): ?>
                <?php foreach ($category as $v): ?>
                    <option value="<?php echo $v['id']; ?>"  <?php echo (isset($product['category_id']) && $product['category_id'] === $v['id']) ? 'selected' : NULL; ?>><?php echo $v['category']; ?></option>
                <?php endforeach; ?>
            <?php endif; ?>
        </select>
    </div>
    <label>Картинка</label>
    <div class="form-group" id="image">
        <input class="form-group" type="file" name="img">
    </div>
    <div class="form-group">
        <label>Название</label>
        <input class="form-control gen_href" name="title" value="<?php echo (isset($product['title'])) ? $product['title'] : NULL; ?>">
    </div>
    <div class="form-group">
        <label>Информация</label>
        <textarea class="form-control" name="info" rows="10"><?php echo (isset($product['info'])) ? $product['info'] : NULL; ?></textarea>
    </div>
    <div class="form-group">
        <label>Видимость</label>
        <select class="form-control" name="visible">
            <?php foreach ($visible as $k => $v): ?>
                <option value="<?php echo $k; ?>" <?php echo (isset($product['visible']) && $product['visible'] == $k) ? 'selected' : NULL; ?>><?php echo $v; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="text-center">
        <button type="submit" class="btn btn-success">Сохранить</button>
    </div>
</form>
<script>
    $(document).ready(function () {

        $(document).change(function () {
            var category = $('#category').val();
            var input = $('#image input')[0];
            if (input.files[0]) {
                var fd = new FormData;
                fd.append('file', input.files[0]);
                fd.append('category', category);
                fd.append('id', '<?php echo (isset($product['id'])) ? $product['id'] : 0; ?>');
                $.ajax({
                    type: 'POST',
                    url: '<?php echo URL::base() . 'admin/products/create' ?>',
                    data: fd,
                    processData: false,
                    contentType: false
                });
            }
        });
    });
</script>
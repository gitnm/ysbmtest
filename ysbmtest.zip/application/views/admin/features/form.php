<div class="row">
    <div class="col-xs-6">
        <form action="<?php echo URL::base() . 'admin/products/feature_save'; ?>" method="POST">
            <div class="form-group hidden">
                <input class="form-group" name="product_id" value="<?php echo (isset($id)) ? $id : NULL; ?>">
            </div>
            <div class="form-group">
                <label> Название</label>
                <input class="form-control" name="name">
            </div>
            <div class="form-group">
                <label> Значение</label>
                <input class="form-control" name="value">
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-success">Сохранить</button>
            </div>
        </form>
    </div>
    <div class="col-xs-6">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>№</th>
                    <th>Название</th>
                    <th>Значение</th>
                    <th>Действие</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($features as $k => $v): ?>
                    <tr>
                        <td><?php echo ($k + 1); ?></td>
                        <td><?php echo $v['name']; ?></td>
                        <td><?php echo $v['value']; ?></td>
                        <td>
                            <i rel="<?php echo URL::base() . 'admin/products/feature_delete/' . $v['id'] ?>" class="fa fa-trash fdelete"></i>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
$(document).ready(function () {
    $('.fdelete').click(function () {
        var a = $(this).attr('rel').split('/');
        var b = $(this);
        $.ajax({
            type: 'POST',
            url: '<?php echo URL::base().'admin/products/feature_delete';?>',
            dataType: 'html',
            data: 'id=' + parseInt(a[a.length - 1]),
            success: function () {
                b.parent().parent().remove();
            }
        });
    });
});
</script>


<?php defined('SYSPATH') or die('No direct script access.');

abstract class Cache extends Kohana_Cache {}